# Q5. Accept a list of names and sort them in alphabetical order using a function.

def sort_names(name_list):
    return sorted(name_list)

names = ["Zara", "Ali", "John", "Emma"]
print("Sorted names:", sort_names(names))
