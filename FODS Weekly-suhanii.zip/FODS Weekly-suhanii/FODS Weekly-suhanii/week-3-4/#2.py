# Q2. Write separate functions for addition, subtraction, multiplication, division, modulo division, and floor division.

def add(a, b): return a + b
def subtract(a, b): return a - b
def multiply(a, b): return a * b
def divide(a, b): return a / b if b != 0 else "Undefined"
def modulo(a, b): return a % b if b != 0 else "Undefined"
def floor_div(a, b): return a // b if b != 0 else "Undefined"

x = int(input("Enter first number: "))
y = int(input("Enter second number: "))

print("Addition:", add(x, y))
print("Subtraction:", subtract(x, y))
print("Multiplication:", multiply(x, y))
print("Division:", divide(x, y))
print("Modulo Division:", modulo(x, y))
print("Floor Division:", floor_div(x, y))
