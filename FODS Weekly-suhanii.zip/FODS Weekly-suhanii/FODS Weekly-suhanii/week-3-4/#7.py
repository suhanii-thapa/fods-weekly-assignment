# Q7. Count the frequency of each word in a sentence using dictionary.

def word_frequency(sentence):
    freq = {}
    words = sentence.lower().split()
    for word in words:
        freq[word] = freq.get(word, 0) + 1
    return freq

print(word_frequency("This is a test. This test is simple."))
