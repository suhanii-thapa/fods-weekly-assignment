# Q10. Accept any number of numbers from user until “exit” is typed, and display even and odd numbers separately.

even, odd = [], []

while True:
    num = input("Enter a number (or type 'exit' to finish): ")
    if num.lower() == 'exit':
        break
    if num.isdigit():
        num = int(num)
        if num % 2 == 0:
            even.append(num)
        else:
            odd.append(num)

print("Even Numbers:", even)
print("Odd Numbers:", odd)
