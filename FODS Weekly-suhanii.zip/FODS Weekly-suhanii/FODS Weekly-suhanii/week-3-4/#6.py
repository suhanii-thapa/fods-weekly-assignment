# Q6. Accept a list of cities and search for a city in it using a function.

def search_city(city_list, city_name):
    if city_name in city_list:
        return city_list.index(city_name)
    else:
        return "City not found in list."

cities = ["Paris", "Lyon", "Nice", "Marseille"]
print(search_city(cities, "Lyon"))
