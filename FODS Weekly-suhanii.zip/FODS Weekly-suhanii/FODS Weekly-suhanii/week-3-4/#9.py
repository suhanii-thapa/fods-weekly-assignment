# Q9. Create a dictionary to store title, author, ISBN, and cost for 5 books. Display the data.

books = {}
for i in range(5):
    title = input(f"Enter title of book {i+1}: ")
    author = input("Author: ")
    isbn = input("ISBN: ")
    cost = float(input("Cost: "))
    books[title] = {"Author": author, "ISBN": isbn, "Cost": cost}

print("Book Details:")
for title, details in books.items():
    print(f"Title: {title}, Author: {details['Author']}, ISBN: {details['ISBN']}, Cost: {details['Cost']}")
