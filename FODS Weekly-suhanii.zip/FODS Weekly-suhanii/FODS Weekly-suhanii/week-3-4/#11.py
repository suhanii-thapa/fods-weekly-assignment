import random

def create_deck():
    suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
    ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
    return [f"{rank} of {suit}" for suit in suits for rank in ranks]

def pick_card(deck):
    return random.choice(deck)

def get_guess():
    valid_ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
    valid_suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']

    print("Guess the card!")

    while True:
        rank = input("Enter rank (2-10, Jack, Queen, King, Ace): ").strip().capitalize()
        if rank not in valid_ranks:
            print("Invalid rank. Try again.")
            continue
        suit = input("Enter suit (Hearts, Diamonds, Clubs, Spades): ").strip().capitalize()
        if suit not in valid_suits:
            print("Invalid suit. Try again.")
            continue
        return f"{rank} of {suit}"

def check_guess(guess, card):
    try:
        guess_rank, guess_suit = guess.split(' of ')
        card_rank, card_suit = card.split(' of ')
    except ValueError:
        return "invalid"

    if guess == card:
        return "correct"
    elif guess_rank == card_rank or guess_suit == card_suit:
        return "partial"
    else:
        return "wrong"

def display_message(result, card):
    if result == "correct":
        print(f"🎉 Congratulations! You guessed the card correctly: {card}")
    elif result == "partial":
        print(f"👍 Close! You guessed either the rank or the suit correctly. The card was: {card}")
    elif result == "invalid":
        print(f"⚠️ Invalid guess format. The card was: {card}")
    else:
        print(f"❌ Sorry, wrong guess. The card was: {card}")

def main():
    deck = create_deck()
    card = pick_card(deck)
    guess = get_guess()
    result = check_guess(guess, card)
    display_message(result, card)

if __name__ == "__main__":
    main()
