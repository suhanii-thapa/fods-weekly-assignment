# Q4. Count how many times each number occurs in a list using functions.

def count_occurrences(numbers):
    for num in set(numbers):
        print(f"{num} occurs {numbers.count(num)} times")

count_occurrences([1, 2, 3, 2, 4, 3, 2])
