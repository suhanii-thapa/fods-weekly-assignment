# Q1. Write a function that takes two numbers and displays their sum, difference, product, and remainder.

def calculate(a, b):
    print("Sum:", a + b)
    print("Difference:", a - b)
    print("Product:", a * b)
    print("Remainder:", a % b)

# Example
calculate(10, 3)
