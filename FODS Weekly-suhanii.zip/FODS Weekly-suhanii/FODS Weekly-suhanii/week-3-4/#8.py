# Q8. Accept numbers from user and remove all duplicates using a set.

def remove_duplicates(numbers):
    return list(set(numbers))

nums = list(map(int, input("Enter numbers separated by space: ").split()))
print("Unique numbers:", remove_duplicates(nums))
