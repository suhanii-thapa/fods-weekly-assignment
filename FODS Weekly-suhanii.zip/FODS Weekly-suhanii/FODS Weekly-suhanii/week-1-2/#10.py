# Q10: Sum of odd and even numbers continuously input until user exits
even_sum = 0
odd_sum = 0

while True:
    num = input("Enter a number (or type 'exit' to quit): ")
    if num.lower() == 'exit':
        break
    if num.isdigit():
        num = int(num)
        if num % 2 == 0:
            even_sum += num
        else:
            odd_sum += num
    else:
        print("Invalid input.")

print("Sum of Even numbers:", even_sum)
print("Sum of Odd numbers:", odd_sum)
