# Q6: Input marks for 5 subjects, calculate total, average, percentage and division
marks = []
for i in range(5):
    marks.append(float(input(f"Enter marks for subject {i+1}: ")))

total = sum(marks)
average = total / 5
percentage = (total / 500) * 100

print("Total:", total)
print("Average:", average)
print("Percentage:", percentage)

if percentage >= 80:
    print("Division: Distinction")
elif percentage > 60:
    print("Division: First")
elif percentage > 50:
    print("Division: Second")
elif percentage > 45:
    print("Division: Third")
else:
    print("Division: Fail")
