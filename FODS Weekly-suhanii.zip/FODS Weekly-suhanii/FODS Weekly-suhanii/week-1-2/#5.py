# Q5: Solve algebraic expressions with inputs a, b, c
a = int(input("Enter value for a: "))
b = int(input("Enter value for b: "))
c = int(input("Enter value for c: "))

expr1 = a**2 + 2*a*b + b**2
expr2 = a**5 + 2*a*b*c + b**3 + c**4
expr3 = a**7 + 5*(a**3)*(b**2)*(c**6) + b**7

print("Expression 1 result:", expr1)
print("Expression 2 result:", expr2)
print("Expression 3 result:", expr3)
1