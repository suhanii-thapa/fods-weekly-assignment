# Q9: Calculate factorial of number input with validation
num = input("Enter a number: ")
if num.isdigit():
    num = int(num)
    factorial = 1
    for i in range(1, num + 1):
        factorial *= i
    print("Factorial is:", factorial)
else:
    print("Not a number.")
