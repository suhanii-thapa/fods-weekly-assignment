# Q8: Numbers divisible by 7 but not multiple of 5 between 2000 and 3200
# Fixed range
for num in range(2000, 3201):
    if num % 7 == 0 and num % 5 != 0:
        print(num, end=', ')

# User input range
start = int(input("\nEnter start of range: "))
end = int(input("Enter end of range: "))
for num in range(start, end + 1):
    if num % 7 == 0 and num % 5 != 0:
        print(num, end=', ')
