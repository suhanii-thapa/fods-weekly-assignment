#2. Write a program to input 2 numbers from the users and display the output of below mentioned operations in a proper format.
#I.	Addition
#II.	Subtraction
#III.	Multiplication
#IV.	Division
#V.	Modulo division
#VI.	Floor division



a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

print(f"Addition: {a} + {b} = {a + b}")
print(f"Subtraction: {a} - {b} = {a - b}")
print(f"Multiplication: {a} * {b} = {a * b}")
print(f"Division: {a} / {b} = {a / b}")
print(f"Modulo Division: {a} % {b} = {a % b}")
print(f"Floor Division: {a} // {b} = {a // b}")


