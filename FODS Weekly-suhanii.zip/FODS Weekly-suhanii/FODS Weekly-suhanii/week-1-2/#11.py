# Q11: Number guessing game with max 5 attempts and feedback
import random

answer = random.randint(1, 100)
attempts = 0
max_attempts = 5

while attempts < max_attempts:
    guess = int(input(f"Attempt {attempts+1}: Guess the number: "))
    if guess == answer:
        print("Correct number!")
        break
    elif guess < answer:
        print("Too low.")
    else:
        print("Too high.")
    attempts += 1

if attempts == max_attempts and guess != answer:
    print("Game Over. The number was:", answer)
