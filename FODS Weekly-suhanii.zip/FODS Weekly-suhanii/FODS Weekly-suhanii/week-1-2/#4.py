# Q4: Perform mathematical calculations on user input number
import math

num = float(input("Enter a number: "))
print("Square:", num ** 2)
print("Square Root:", math.sqrt(num))
print("Exponent Value (e^x):", math.exp(num))
print("Log base 10:", math.log10(num))
print("Power of 3:", num ** 3)
print("Power of 4:", num ** 4)
print("Power of 5:", num ** 5)
