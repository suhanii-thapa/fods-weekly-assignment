# Question 8:
# Write a program to implement a basic library book management with the functionalities such as issue the book, return the book and search the book. 
# Use the concept of OOP to create the necessary classes on your own and implement the concept of other OOP features. 
# For the storage of book details, use the file handling along with the exception handling.

import json

class Book:
    def __init__(self, book_id, title, author, issued=False):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.issued = issued

    def to_dict(self):
        return {
            "book_id": self.book_id,
            "title": self.title,
            "author": self.author,
            "issued": self.issued
        }

class Library:
    def __init__(self, filename="library_books.json"):
        self.filename = filename
        self.books = []
        self.load_books()

    def load_books(self):
        try:
            with open(self.filename, 'r') as file:
                data = json.load(file)
                self.books = [Book(**book) for book in data]
        except FileNotFoundError:
            self.books = []
        except json.JSONDecodeError:
            self.books = []

    def save_books(self):
        with open(self.filename, 'w') as file:
            json.dump([book.to_dict() for book in self.books], file, indent=4)

    def add_book(self, book):
        self.books.append(book)
        self.save_books()

    def search_book(self, title):
        results = [book for book in self.books if title.lower() in book.title.lower()]
        return results

    def issue_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id:
                if not book.issued:
                    book.issued = True
                    self.save_books()
                    return f"Book '{book.title}' issued."
                else:
                    return "Book is already issued."
        return "Book not found."

    def return_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id:
                if book.issued:
                    book.issued = False
                    self.save_books()
                    return f"Book '{book.title}' returned."
                else:
                    return "Book was not issued."
        return "Book not found."

# Example usage
lib = Library()
# Add a book
lib.add_book(Book("001", "Python Programming", "John Doe"))

# Search book
books_found = lib.search_book("python")
for b in books_found:
    print(f"Found: {b.title} by {b.author}")

# Issue a book
print(lib.issue_book("001"))

# Return a book
print(lib.return_book("001"))
