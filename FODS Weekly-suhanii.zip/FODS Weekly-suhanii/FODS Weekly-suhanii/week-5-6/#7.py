# Question 7:
# Write a program to implement a class called employee with attributes such as empid, name, address, contact_number, 
# spouse_name, number_of_child, salary. Instantiate this class to input the values for multiple employees and write it in a file “employees.csv”. 
# Allow the user of your program to see the list of employees and their details as well. Try to use the concept of try/except too in the program.

import csv

class Employee:
    def __init__(self, empid, name, address, contact_number, spouse_name, number_of_child, salary):
        self.empid = empid
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.spouse_name = spouse_name
        self.number_of_child = number_of_child
        self.salary = salary

    def to_list(self):
        return [self.empid, self.name, self.address, self.contact_number, self.spouse_name, str(self.number_of_child), str(self.salary)]

def add_employees(filename="employees.csv"):
    try:
        with open(filename, 'a', newline='') as file:
            writer = csv.writer(file)
            while True:
                empid = input("Enter Employee ID: ")
                name = input("Enter Name: ")
                address = input("Enter Address: ")
                contact = input("Enter Contact Number: ")
                spouse = input("Enter Spouse Name: ")
                children = int(input("Enter Number of Children: "))
                salary = float(input("Enter Salary: "))

                emp = Employee(empid, name, address, contact, spouse, children, salary)
                writer.writerow(emp.to_list())

                more = input("Add another employee? (y/n): ").lower()
                if more != 'y':
                    break
    except Exception as e:
        print("Error:", e)

def show_employees(filename="employees.csv"):
    try:
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            print("\nEmployees List:")
            for row in reader:
                print(f"ID: {row[0]}, Name: {row[1]}, Address: {row[2]}, Contact: {row[3]}, Spouse: {row[4]}, Children: {row[5]}, Salary: {row[6]}")
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")

# Example usage:
add_employees()
show_employees()
