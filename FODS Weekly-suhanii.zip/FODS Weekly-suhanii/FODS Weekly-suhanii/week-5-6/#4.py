# Question 4:
# Write a program to take read a file and write it into another file. The input and output file names should be taken input from the user. 
# Use the concept of try/except to handle the exception. Provide the proper error if the file does not exist while reading 
# and also if the file for output exists.

def copy_file():
    input_file = input("Enter the input filename: ")
    output_file = input("Enter the output filename: ")

    try:
        with open(input_file, 'r') as infile:
            content = infile.read()
    except FileNotFoundError:
        print(f"Error: '{input_file}' not found.")
        return
    
    try:
        with open(output_file, 'x') as outfile:  # 'x' mode for create only if not exists
            outfile.write(content)
        print(f"File copied to '{output_file}'.")
    except FileExistsError:
        print(f"Error: '{output_file}' already exists.")

copy_file()
