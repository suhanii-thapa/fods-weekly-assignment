# Question 2:
# Write a program to take the user details as the input from the user and write it to the existing file “students.csv”. 
# The new record should be added to the end of the file. The fields to take input are name, id, course, level and section.

import csv

def append_student(filename="students.csv"):
    name = input("Enter name: ")
    id_ = input("Enter ID: ")
    course = input("Enter course: ")
    level = input("Enter level: ")
    section = input("Enter section: ")
    
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, id_, course, level, section])
    print("Record added successfully.")

append_student()
