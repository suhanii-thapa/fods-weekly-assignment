# Question 3:
# Write a program input any list of numbers from the user, calculate the addition, subtraction, multiplication and division values 
# and write into a file with the current date and time. The program should allow the user to repeat the operation until they want. 
# When the user choose the option to exit the program, the user should be displayed with the details in the current file in a proper format.

from datetime import datetime

def calculate_operations(nums):
    addition = sum(nums)
    subtraction = nums[0]
    multiplication = 1
    for n in nums:
        multiplication *= n
    division = nums[0]
    for n in nums[1:]:
        if n != 0:
            division /= n
        else:
            division = "undefined (division by zero)"
            break
    return addition, subtraction, multiplication, division

def main():
    filename = "operations_log.txt"
    while True:
        user_input = input("Enter numbers separated by space: ")
        nums = list(map(float, user_input.split()))
        add, sub, mul, div = calculate_operations(nums)
        
        with open(filename, "a") as f:
            f.write(f"{datetime.now()} - Numbers: {nums}\n")
            f.write(f"Addition: {add}, Subtraction: {sub}, Multiplication: {mul}, Division: {div}\n\n")
        
        cont = input("Do you want to perform another operation? (y/n): ").lower()
        if cont != 'y':
            break
    
    print("\n--- Operations Log ---")
    with open(filename, "r") as f:
        print(f.read())

main()
