import csv
import os

def add_student_data(filename):
    print("Enter student details:")
    name = input("Name: ").strip()
    student_id = input("ID: ").strip()
    course = input("Course: ").strip()
    level = input("Level: ").strip()
    section = input("Section: ").strip()

    file_exists = os.path.isfile(filename)

    with open(filename, mode='a', newline='') as file:
        fieldnames = ['name', 'id', 'course', 'level', 'section']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        
        # Write header only if file didn't exist before
        if not file_exists:
            writer.writeheader()
        
        writer.writerow({
            'name': name,
            'id': student_id,
            'course': course,
            'level': level,
            'section': section
        })
    print("Student data added successfully.\n")

def read_students_file(filename):
    try:
        with open(filename, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            print("Current students in the file:")
            for row in reader:
                print(f"Name: {row.get('name')}, ID: {row.get('id')}, Course: {row.get('course')}, Level: {row.get('level')}, Section: {row.get('section')}")
    except FileNotFoundError:
        print(f"The file {filename} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

def main():
    filename = 'students.csv'
    add_student_data(filename)
    read_students_file(filename)

if __name__ == "__main__":
    main()
