# Question 6:
# Write a program to create a class called recipe with the attributes such as id, name, ingredients, descriptions. 
# Create another class called recipe book to manage the collection of recipes.

class Recipe:
    def __init__(self, id_, name, ingredients, description):
        self.id = id_
        self.name = name
        self.ingredients = ingredients  # list of ingredients
        self.description = description

    def display(self):
        print(f"Recipe ID: {self.id}")
        print(f"Name: {self.name}")
        print(f"Ingredients: {', '.join(self.ingredients)}")
        print(f"Description: {self.description}")

class RecipeBook:
    def __init__(self):
        self.recipes = []

    def add_recipe(self, recipe):
        self.recipes.append(recipe)

    def show_all(self):
        for r in self.recipes:
            print("-" * 20)
            r.display()

# Example usage
rb = RecipeBook()
r1 = Recipe(1, "Pancakes", ["flour", "milk", "egg", "sugar"], "Mix and cook on pan.")
rb.add_recipe(r1)
rb.show_all()
