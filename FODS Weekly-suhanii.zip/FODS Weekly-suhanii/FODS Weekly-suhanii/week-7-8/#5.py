import pandas as pd
import matplotlib.pyplot as plt
import os

# Check if file exists
file_name = 'weight_height.csv'
if not os.path.exists(file_name):
    print(f"❌ File '{file_name}' not found!")
    exit()

# Load the CSV
df = pd.read_csv(file_name)

# Print the first 5 rows
print("✅ File loaded successfully:")
print(df.head())

# Check if all required columns are present
required_columns = ['Weight', 'Height', 'Age', 'Gender']
for col in required_columns:
    if col not in df.columns:
        print(f"❌ Missing column: {col}")
        exit()

# Weight vs Height
plt.figure()
plt.scatter(df['Height'], df['Weight'], alpha=0.6, c='blue')
plt.title('Weight vs Height')
plt.xlabel('Height')
plt.ylabel('Weight')
plt.grid(True)
plt.show()

# Age vs Weight
plt.figure()
plt.scatter(df['Age'], df['Weight'], alpha=0.6, c='green')
plt.title('Age vs Weight')
plt.xlabel('Age')
plt.ylabel('Weight')
plt.grid(True)
plt.show()

# Height vs Age
plt.figure()
plt.scatter(df['Age'], df['Height'], alpha=0.6, c='red')
plt.title('Height vs Age')
plt.xlabel('Age')
plt.ylabel('Height')
plt.grid(True)
plt.show()

# Gender vs Height
plt.figure()
plt.scatter(df['Gender'], df['Height'], alpha=0.6, c='purple')
plt.title('Gender vs Height')
plt.xlabel('Gender')
plt.ylabel('Height')
plt.grid(True)
plt.show()

# Gender vs Weight
plt.figure()
plt.scatter(df['Gender'], df['Weight'], alpha=0.6, c='orange')
plt.title('Gender vs Weight')
plt.xlabel('Gender')
plt.ylabel('Weight')
plt.grid(True)
plt.show()
