# Input list from user
user_input = input("Enter at least 10 numbers separated by spaces: ")
num_list = list(map(int, user_input.split()))

if len(num_list) < 10:
    print("Please enter at least 10 elements.")
else:
    num_list.sort()
    print("Sorted List:", num_list)
    print("Elements from index 2 to 5:", num_list[2:6])
    print("Elements from index 5 to 8:", num_list[5:9])
    print("Elements from index 2 to 9:", num_list[2:10])
