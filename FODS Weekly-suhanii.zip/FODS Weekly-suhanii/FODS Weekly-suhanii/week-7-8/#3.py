import numpy as np

# Generate random integers
arr = np.random.randint(1, 100, size=10)
print("Original array:", arr)

# Sort array
arr_sorted = np.sort(arr)
print("Sorted array:", arr_sorted)

# Reshape array to feasible shape
reshaped = arr_sorted.reshape(2, 5)  # or .reshape(5, 2)
print("Reshaped to 2x5 matrix:\n", reshaped)
