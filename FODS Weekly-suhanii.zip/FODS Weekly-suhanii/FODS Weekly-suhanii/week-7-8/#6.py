import pandas as pd

# Load the CSV
df = pd.read_csv("weight_height.csv")

# Calculate BMI = Weight / Height
df['BMI'] = df['Weight'] / df['Height']

# Add 'Risk' based on BMI value
def assess_risk(bmi):
    if bmi < 18.5:
        return "Nutrient deficient"
    elif 18.5 <= bmi <= 24.9:
        return "Lower risk"
    elif 25 <= bmi <= 29.9:
        return "Heart disease risk"
    elif 30 <= bmi <= 34.9:
        return "High diabetes/heart risk"
    elif bmi >= 40:
        return "Serious health risk"
    else:
        return "Moderate risk"

# Apply risk assessment function
df['Risk'] = df['BMI'].apply(assess_risk)

# Display updated DataFrame
print(df[['Weight', 'Height', 'BMI', 'Risk']].head())

# Optionally save to new file
df.to_csv("updated_weight_height.csv", index=False)
