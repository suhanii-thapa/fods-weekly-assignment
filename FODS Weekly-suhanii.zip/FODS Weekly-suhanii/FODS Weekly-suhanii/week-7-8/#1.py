import numpy as np

# Generate numpy array
arr = np.array([1, 2, 3, 4, 5])

# Operations
print("Array:", arr)
print("Sum:", np.sum(arr))
print("Average:", np.mean(arr))
print("Max:", np.max(arr))
print("Min:", np.min(arr))
