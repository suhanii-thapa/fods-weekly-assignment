import numpy as np

def input_matrix(name):
    r = int(input(f"Enter number of rows for {name}: "))
    c = int(input(f"Enter number of columns for {name}: "))
    print(f"Enter elements for {name}:")
    elements = []
    for i in range(r):
        row = list(map(int, input(f"Row {i+1}: ").split()))
        elements.append(row)
    return np.array(elements)

try:
    A = input_matrix("Matrix A")
    B = input_matrix("Matrix B")
    
    if A.shape != B.shape:
        raise ValueError("Matrix dimensions do not match!")
    
    print("Addition:\n", A + B)
    print("Subtraction:\n", A - B)
    print("Multiplication (Element-wise):\n", A * B)

except Exception as e:
    print("Error:", e)
